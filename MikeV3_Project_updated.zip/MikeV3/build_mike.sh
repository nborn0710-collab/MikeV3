#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
gradle assembleDebug --no-daemon
cp -f app/build/outputs/apk/debug/app-debug.apk "$HOME/storage/downloads/Mike-3.0.apk"
echo "APK: $HOME/storage/downloads/Mike-3.0.apk"
