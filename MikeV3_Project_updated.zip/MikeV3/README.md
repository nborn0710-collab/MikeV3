# MIKE 3.0 — A.K DEVELOPERS

Modern Android voice assistant for Hindi, English and Hinglish voice commands. All visible UI text is English.

Features: speech recognition, Hindi/English TTS, dynamic installed-app launching, calls and SMS/WhatsApp with confirmation, accessibility controls (Home, Back, Tap text, Long-press, Scroll, Notifications, Quick Settings), search, YouTube search, time/date, battery, calculator, volume control, and a Settings screen (default city, TTS speed, always-listening toggle).

New in this build:
- **Settings screen** — set a default city for weather, adjust TTS speech rate, toggle "always listening" mode. Open by voice ("open settings") or the Settings button.
- **Offline weather fallback** — if there's no internet, Mike answers with the last successful weather reading and says how old it is, instead of just failing.
- **Wake-word-lite ("always listening") mode** — toggle it on in Settings, tap TAP TO SPEAK once, and Mike keeps re-listening on its own; it only reacts to phrases starting with "Hey Mike" / "Mike" / "Okay Mike" and ignores everything else.
- **Volume control** — "volume up/down", "mute", "unmute", "set volume to 40 percent".
- **More accessibility commands** — "long press <item>", "open notifications", "quick settings".
- Removed old `.backup_*` development snapshots and build output from the project; added `.gitignore`.

Install the APK, grant microphone/contacts/phone/SMS permissions, and enable MIKE under Android Accessibility settings for app-control commands.

Not yet done (still worth adding later): true always-on wake word without tapping once first (needs a background/foreground service, since Android restricts mic access for a plain Activity when it's not in the foreground), on-device offline speech recognition, and multi-step conversation context (e.g. "call him back").

WhatsApp and other apps can have different Android restrictions; the assistant does not bypass those restrictions.
