package com.akdevelopers.mike;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.KeyEvent;
import java.util.ArrayList;
import java.util.Locale;

/**
 * True hands-free mode: a foreground service (survives the screen being off / the app
 * being closed) that keeps re-listening for "Hey Mike" and handles a set of SAFE, quick
 * commands entirely on its own (time, battery, flashlight, volume, music). Anything more
 * involved (calls, messages, WhatsApp, alarms, weather, opening apps, hologram, settings)
 * is handed off to MainActivity, which wakes the screen and runs it through the full
 * command set there — those stay behind the normal on-screen confirmation for safety.
 *
 * Known limitation: Android aggressively restricts background microphone use to save
 * battery, and some phone brands (this one included, based on earlier testing) kill
 * background services unless the app is whitelisted in battery/autostart settings. If
 * hands-free mode stops responding after a while, check Settings > Battery > Background
 * permission for MIKE.
 */
public class MikeBackgroundService extends Service {

    static final String CHANNEL_ID="mike_handsfree";
    static final int NOTIF_ID=101;

    SpeechRecognizer sr;
    TextToSpeech tts;
    SharedPreferences prefs;
    Handler handler=new Handler(Looper.getMainLooper());
    boolean listening=false;
    CameraManager cameraManager; String cameraId; boolean flashOn=false;

    @Override public IBinder onBind(Intent i){ return null; }

    @Override
    public void onCreate(){
        super.onCreate();
        prefs=getSharedPreferences(SettingsActivity.PREFS_NAME, MODE_PRIVATE);
        tts=new TextToSpeech(this, status->{ if(status==TextToSpeech.SUCCESS){ tts.setLanguage(Locale.ENGLISH); tts.setSpeechRate(prefs.getInt(SettingsActivity.KEY_SPEECH_RATE,100)/100f); } });
        initFlashlight();
        if(Build.VERSION.SDK_INT>=29){
            startForeground(NOTIF_ID, buildNotification("Listening for \"Hey Mike\"..."), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTIF_ID, buildNotification("Listening for \"Hey Mike\"..."));
        }
        startListenCycle();
    }

    @Override
    public int onStartCommand(Intent intent,int flags,int startId){
        return START_STICKY; // ask Android to restart us if it kills this service
    }

    Notification buildNotification(String text){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=getSystemService(NotificationManager.class);
            if(nm.getNotificationChannel(CHANNEL_ID)==null){
                NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"MIKE Hands-free",NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Shows while MIKE is listening for the wake word in the background.");
                nm.createNotificationChannel(ch);
            }
        }
        Intent tapIntent=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,tapIntent,
            Build.VERSION.SDK_INT>=23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        Notification.Builder b = Build.VERSION.SDK_INT>=26 ? new Notification.Builder(this,CHANNEL_ID) : new Notification.Builder(this);
        b.setContentTitle("MIKE — Hands-free mode")
         .setContentText(text)
         .setSmallIcon(android.R.drawable.ic_btn_speak_now)
         .setContentIntent(pi)
         .setOngoing(true);
        return b.build();
    }

    void updateNotification(String text){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=getSystemService(NotificationManager.class);
            nm.notify(NOTIF_ID, buildNotification(text));
        }
    }

    void startListenCycle(){
        if(sr==null){
            if(SpeechRecognizer.isRecognitionAvailable(this)) sr=SpeechRecognizer.createSpeechRecognizer(this);
            if(sr==null){ stopSelf(); return; }
            sr.setRecognitionListener(new RecognitionListener(){
                public void onReadyForSpeech(Bundle b){}
                public void onBeginningOfSpeech(){}
                public void onRmsChanged(float r){}
                public void onBufferReceived(byte[] b){}
                public void onEndOfSpeech(){}
                public void onError(int e){ listening=false; relisten(); }
                public void onResults(Bundle b){
                    listening=false;
                    ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String raw=(a!=null&&!a.isEmpty())?a.get(0):null;
                    if(raw!=null){
                        String low=raw.toLowerCase(Locale.ROOT).trim();
                        if(low.startsWith("hey mike")||low.startsWith("mike")||low.startsWith("ok mike")||low.startsWith("okay mike")){
                            handleWakeCommand(low);
                        }
                    }
                    relisten();
                }
                public void onPartialResults(Bundle b){}
                public void onEvent(int x,Bundle b){}
            });
        }
        relisten();
    }

    void relisten(){
        // Only keep looping while hands-free is still turned on in Settings.
        if(!prefs.getBoolean(SettingsActivity.KEY_HANDSFREE,false)){ stopSelf(); return; }
        handler.postDelayed(()->{
            if(listening||sr==null) return;
            listening=true;
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-IN");
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);
            try{ sr.startListening(i); }catch(Exception e){ listening=false; }
        },500);
    }

    String stripWake(String low){
        String x=low;
        while(x.matches("^(hey|okay|ok|mike)\\s+.*")) x=x.replaceFirst("^(hey|okay|ok|mike)\\s+","");
        return x.trim();
    }

    void handleWakeCommand(String lowRaw){
        String c=stripWake(lowRaw);
        updateNotification("Heard: "+c);

        // --- Handled fully in the background, no need to open the app or wake the screen ---
        if(c.contains("what time")||c.equals("time")){
            speak(new java.text.SimpleDateFormat("hh:mm a",Locale.ENGLISH).format(new java.util.Date())+".");
            return;
        }
        if(c.contains("battery")){
            try{
                android.os.BatteryManager bm=(android.os.BatteryManager)getSystemService(BATTERY_SERVICE);
                int p=bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY);
                speak("Battery is at "+p+" percent.");
            }catch(Exception e){ speak("I could not check the battery."); }
            return;
        }
        if(c.contains("flashlight")||c.contains("torch")){
            setFlashlight(!c.contains("off"));
            return;
        }
        if(c.contains("mute")&&!c.contains("unmute")){ mediaVolume(AudioManager.ADJUST_MUTE); return; }
        if(c.contains("unmute")){ mediaVolume(AudioManager.ADJUST_UNMUTE); return; }
        if(c.contains("volume")){
            if(c.contains("up")||c.contains("increase")||c.contains("raise")){ mediaVolume(AudioManager.ADJUST_RAISE); return; }
            if(c.contains("down")||c.contains("decrease")||c.contains("lower")){ mediaVolume(AudioManager.ADJUST_LOWER); return; }
        }
        if(c.equals("pause")||c.equals("pause music")){ mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE); speak("Pausing."); return; }
        if(c.equals("play")||c.equals("play music")||c.equals("resume")){ mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY); speak("Playing."); return; }
        if(c.contains("next song")||c.contains("next track")||c.equals("skip")){ mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT); speak("Next track."); return; }
        if(c.contains("previous song")||c.contains("last song")){ mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS); speak("Previous track."); return; }

        // --- Everything else: wake the app up in the foreground and let it run there ---
        Intent open=new Intent(this,MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        open.putExtra("voice_command", c);
        startActivity(open);
    }

    void mediaVolume(int direction){
        try{
            AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC,direction,AudioManager.FLAG_SHOW_UI);
        }catch(Exception ignored){}
    }
    void mediaKey(int keyCode){
        try{
            AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);
            long now=android.os.SystemClock.uptimeMillis();
            am.dispatchMediaKeyEvent(new KeyEvent(now,now,KeyEvent.ACTION_DOWN,keyCode,0));
            am.dispatchMediaKeyEvent(new KeyEvent(now,now,KeyEvent.ACTION_UP,keyCode,0));
        }catch(Exception ignored){}
    }
    void initFlashlight(){
        try{
            cameraManager=(CameraManager)getSystemService(CAMERA_SERVICE);
            for(String id:cameraManager.getCameraIdList()){
                CameraCharacteristics cc=cameraManager.getCameraCharacteristics(id);
                Boolean f=cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer l=cc.get(CameraCharacteristics.LENS_FACING);
                if(Boolean.TRUE.equals(f)&&Integer.valueOf(CameraCharacteristics.LENS_FACING_BACK).equals(l)){ cameraId=id; break; }
            }
        }catch(Exception e){ cameraId=null; }
    }
    void setFlashlight(boolean on){
        try{
            if(cameraId!=null){ cameraManager.setTorchMode(cameraId,on); flashOn=on; speak(on?"Flashlight on.":"Flashlight off."); }
            else speak("Flashlight is not available on this phone.");
        }catch(Exception e){ speak("I could not control the flashlight."); }
    }

    void speak(String text){
        if(tts!=null) tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"mike_bg");
        updateNotification("Said: "+text);
    }

    @Override
    public void onDestroy(){
        if(sr!=null) sr.destroy();
        if(tts!=null){ tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
