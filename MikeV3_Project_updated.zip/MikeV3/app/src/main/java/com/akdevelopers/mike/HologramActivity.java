package com.akdevelopers.mike;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

/**
 * A lightweight "hologram" sandbox for a student's own small projects: a rotating
 * wireframe box you can size to your real project's dimensions (in cm), with a name
 * and notes, saved locally so you can reopen past projects. Also includes a few plain
 * reference shapes (cube/pyramid/sphere) drawn with plain Canvas + basic 3D math
 * (no OpenGL needed). Styled like a JARVIS-style holographic projection.
 */
public class HologramActivity extends Activity {

    HoloView holoView;
    TextView notesOverlay;
    SharedPreferences prefs;
    static final String PROJECTS_KEY="holo_projects";

    int dp(int x){ return (int)(x*getResources().getDisplayMetrics().density+.5f); }

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("mike_hologram", MODE_PRIVATE);
        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2,6,10));

        holoView=new HoloView(this);
        root.addView(holoView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout overlay=new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setPadding(dp(18),dp(18),dp(18),dp(18));

        TextView title=new TextView(this);
        title.setText("HOLOGRAM MODE");
        title.setTextColor(Color.rgb(0,230,255));
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        overlay.addView(title);

        notesOverlay=new TextView(this);
        notesOverlay.setText("Drag to rotate  |  release to auto-spin");
        notesOverlay.setTextColor(Color.rgb(0,160,190));
        notesOverlay.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        notesOverlay.setTextSize(11);
        notesOverlay.setGravity(Gravity.CENTER);
        notesOverlay.setMaxLines(4);
        LinearLayout.LayoutParams subLp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        subLp.topMargin=dp(4);
        overlay.addView(notesOverlay, subLp);

        // Project buttons: New / My Projects
        LinearLayout projRow=new LinearLayout(this); projRow.setOrientation(LinearLayout.HORIZONTAL); projRow.setWeightSum(2);
        Button newProj=new Button(this); newProj.setText("[ NEW PROJECT ]"); newProj.setAllCaps(false); newProj.setTextSize(12); newProj.setTextColor(Color.rgb(0,230,255)); newProj.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); newProj.setBackgroundColor(Color.argb(70,5,25,30)); newProj.setOnClickListener(v->showNewProjectDialog());
        Button myProj=new Button(this); myProj.setText("[ MY PROJECTS ]"); myProj.setAllCaps(false); myProj.setTextSize(12); myProj.setTextColor(Color.rgb(0,230,255)); myProj.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); myProj.setBackgroundColor(Color.argb(70,5,25,30)); myProj.setOnClickListener(v->showProjectListDialog());
        LinearLayout.LayoutParams npLp=new LinearLayout.LayoutParams(0,dp(48),1); npLp.rightMargin=dp(6);
        LinearLayout.LayoutParams mpLp=new LinearLayout.LayoutParams(0,dp(48),1); mpLp.leftMargin=dp(6);
        projRow.addView(newProj,npLp); projRow.addView(myProj,mpLp);
        LinearLayout.LayoutParams prLp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        prLp.topMargin=dp(14);
        overlay.addView(projRow, prLp);

        // Shape switch buttons, pinned to the bottom
        LinearLayout shapeRow=new LinearLayout(this);
        shapeRow.setOrientation(LinearLayout.HORIZONTAL);
        shapeRow.setWeightSum(4);
        shapeRow.addView(shapeBtn("CUBE", HoloView.Shape.CUBE));
        shapeRow.addView(shapeBtn("PYRAMID", HoloView.Shape.PYRAMID));
        shapeRow.addView(shapeBtn("SPHERE", HoloView.Shape.SPHERE));
        Button backBtn=new Button(this);
        backBtn.setText("[ BACK ]");
        backBtn.setAllCaps(false);
        backBtn.setTextColor(Color.rgb(255,170,0));
        backBtn.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        backBtn.setBackgroundColor(Color.argb(60,20,15,5));
        backBtn.setOnClickListener(v->finish());
        LinearLayout.LayoutParams backLp=new LinearLayout.LayoutParams(0, dp(52),1); backLp.leftMargin=dp(6);
        shapeRow.addView(backBtn, backLp);

        FrameLayout.LayoutParams rowFrame=new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        rowFrame.bottomMargin=dp(24); rowFrame.leftMargin=dp(18); rowFrame.rightMargin=dp(18);
        root.addView(shapeRow, rowFrame);

        root.addView(overlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    void showNewProjectDialog(){
        LinearLayout form=new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(20),dp(10),dp(20),dp(10));
        EditText name=fieldInput("Project name (e.g. Bridge model)", InputType.TYPE_CLASS_TEXT);
        EditText w=fieldInput("Width (cm)", InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText h=fieldInput("Height (cm)", InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText d=fieldInput("Depth (cm)", InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText notes=fieldInput("Notes / what this project is for", InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        notes.setMinLines(3);
        form.addView(label("Name")); form.addView(name);
        form.addView(label("Dimensions (cm)")); 
        LinearLayout dims=new LinearLayout(this); dims.setOrientation(LinearLayout.HORIZONTAL);
        dims.addView(w,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        dims.addView(h,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        dims.addView(d,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        form.addView(dims);
        form.addView(label("Notes")); form.addView(notes);

        new AlertDialog.Builder(this)
            .setTitle("New Project")
            .setView(form)
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Show + Save",(dg,which)->{
                String pname=name.getText().toString().trim(); if(pname.isEmpty()) pname="Untitled project";
                float fw=parseOr(w.getText().toString(),5f), fh=parseOr(h.getText().toString(),5f), fd=parseOr(d.getText().toString(),5f);
                String pnotes=notes.getText().toString().trim();
                holoView.setCustomBox(fw,fh,fd);
                notesOverlay.setText(pname+"  •  "+fw+"×"+fh+"×"+fd+" cm"+(pnotes.isEmpty()?"":"\n"+pnotes));
                saveProject(pname,fw,fh,fd,pnotes);
                Toast.makeText(this,"Project saved.",Toast.LENGTH_SHORT).show();
            }).show();
    }

    EditText fieldInput(String hint,int type){
        EditText e=new EditText(this); e.setHint(hint); e.setInputType(type); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY);
        return e;
    }
    TextView label(String s){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.rgb(0,200,230)); t.setTextSize(12); t.setPadding(0,dp(10),0,dp(2)); return t; }
    float parseOr(String s,float def){ try{ return Float.parseFloat(s.trim()); }catch(Exception e){ return def; } }

    void saveProject(String name,float w,float h,float d,String notes){
        try{
            JSONArray arr=loadProjectsArray();
            JSONObject o=new JSONObject();
            o.put("name",name); o.put("w",w); o.put("h",h); o.put("d",d); o.put("notes",notes); o.put("time",System.currentTimeMillis());
            arr.put(o);
            prefs.edit().putString(PROJECTS_KEY, arr.toString()).apply();
        }catch(Exception ignored){}
    }
    JSONArray loadProjectsArray(){
        try{ return new JSONArray(prefs.getString(PROJECTS_KEY,"[]")); }catch(Exception e){ return new JSONArray(); }
    }

    void showProjectListDialog(){
        JSONArray arr=loadProjectsArray();
        if(arr.length()==0){ Toast.makeText(this,"No saved projects yet. Tap NEW PROJECT first.",Toast.LENGTH_LONG).show(); return; }
        ArrayList<String> labels=new ArrayList<>();
        final ArrayList<Integer> realIndices=new ArrayList<>();
        for(int i=arr.length()-1;i>=0;i--){
            try{ JSONObject o=arr.getJSONObject(i); labels.add(o.getString("name")+"  ("+o.getDouble("w")+"×"+o.getDouble("h")+"×"+o.getDouble("d")+" cm)"); realIndices.add(i); }catch(Exception ignored){}
        }
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels);
        ListView lv=new ListView(this); lv.setAdapter(adapter);
        AlertDialog dlg=new AlertDialog.Builder(this)
            .setTitle("My Projects  (long-press to delete)")
            .setView(lv)
            .setNegativeButton("Close",null)
            .create();
        lv.setOnItemClickListener((parent,view,position,id)->{
            try{
                JSONObject o=arr.getJSONObject(realIndices.get(position));
                float fw=(float)o.getDouble("w"), fh=(float)o.getDouble("h"), fd=(float)o.getDouble("d");
                String pname=o.getString("name"); String pnotes=o.optString("notes","");
                holoView.setCustomBox(fw,fh,fd);
                notesOverlay.setText(pname+"  •  "+fw+"×"+fh+"×"+fd+" cm"+(pnotes.isEmpty()?"":"\n"+pnotes));
            }catch(Exception ignored){}
            dlg.dismiss();
        });
        lv.setOnItemLongClickListener((parent,view,position,id)->{
            int idx=realIndices.get(position);
            JSONArray fresh=loadProjectsArray();
            JSONArray rebuilt=new JSONArray();
            for(int i=0;i<fresh.length();i++){ if(i!=idx){ try{ rebuilt.put(fresh.getJSONObject(i)); }catch(Exception ignored){} } }
            prefs.edit().putString(PROJECTS_KEY, rebuilt.toString()).apply();
            Toast.makeText(this,"Project deleted.",Toast.LENGTH_SHORT).show();
            dlg.dismiss();
            return true;
        });
        dlg.show();
    }

    Button shapeBtn(String label, HoloView.Shape shape){
        Button b=new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(11);
        b.setTextColor(Color.rgb(0,220,255));
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setBackgroundColor(Color.argb(60,5,25,30));
        b.setOnClickListener(v->{ holoView.setShape(shape); notesOverlay.setText("Drag to rotate  |  release to auto-spin"); });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0, dp(52),1); lp.rightMargin=dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    @Override protected void onPause(){ super.onPause(); if(holoView!=null) holoView.pauseSpin(); }
    @Override protected void onResume(){ super.onResume(); if(holoView!=null) holoView.resumeSpin(); }

    // ---- The actual wireframe renderer ----
    static class HoloView extends View {
        enum Shape { CUBE, PYRAMID, SPHERE, CUSTOM }
        Shape current=Shape.CUBE;
        float customW=5,customH=5,customD=5;
        float[][] verts; int[][] edges;
        float yaw=0.5f, pitch=0.4f;
        float autoSpinSpeed=0.012f;
        boolean dragging=false;
        float lastX, lastY;
        boolean running=true;
        Paint linePaint, glowPaint, gridPaint, scanPaint;

        HoloView(Context c){
            super(c);
            linePaint=new Paint(Paint.ANTI_ALIAS_FLAG); linePaint.setColor(Color.rgb(120,240,255)); linePaint.setStrokeWidth(3.5f); linePaint.setStyle(Paint.Style.STROKE);
            glowPaint=new Paint(Paint.ANTI_ALIAS_FLAG); glowPaint.setColor(Color.argb(70,0,220,255)); glowPaint.setStrokeWidth(9f); glowPaint.setStyle(Paint.Style.STROKE);
            gridPaint=new Paint(Paint.ANTI_ALIAS_FLAG); gridPaint.setColor(Color.argb(40,0,180,210)); gridPaint.setStrokeWidth(1f);
            scanPaint=new Paint(Paint.ANTI_ALIAS_FLAG); scanPaint.setColor(Color.argb(14,0,255,255));
            buildShape(Shape.CUBE);
            setClickable(true);
            postInvalidateLoop();
        }

        void setShape(Shape s){ current=s; buildShape(s); invalidate(); }
        void setCustomBox(float w,float h,float d){ customW=w; customH=h; customD=d; current=Shape.CUSTOM; buildShape(Shape.CUSTOM); invalidate(); }

        void buildShape(Shape s){
            if(s==Shape.CUBE){
                verts=new float[][]{
                    {-1,-1,-1},{1,-1,-1},{1,1,-1},{-1,1,-1},
                    {-1,-1,1},{1,-1,1},{1,1,1},{-1,1,1}
                };
                edges=new int[][]{{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
            } else if(s==Shape.CUSTOM){
                float maxDim=Math.max(customW,Math.max(customH,customD)); if(maxDim<=0) maxDim=1;
                float hx=customW/maxDim, hy=customH/maxDim, hz=customD/maxDim;
                verts=new float[][]{
                    {-hx,-hy,-hz},{hx,-hy,-hz},{hx,hy,-hz},{-hx,hy,-hz},
                    {-hx,-hy,hz},{hx,-hy,hz},{hx,hy,hz},{-hx,hy,hz}
                };
                edges=new int[][]{{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
            } else if(s==Shape.PYRAMID){
                verts=new float[][]{
                    {-1,1,-1},{1,1,-1},{1,1,1},{-1,1,1},
                    {0,-1,0}
                };
                edges=new int[][]{{0,1},{1,2},{2,3},{3,0},{0,4},{1,4},{2,4},{3,4}};
            } else { // SPHERE (lat/long wireframe)
                int lat=8, lon=12;
                java.util.List<float[]> vlist=new java.util.ArrayList<>();
                java.util.List<int[]> elist=new java.util.ArrayList<>();
                for(int i=0;i<=lat;i++){
                    double theta=Math.PI*i/lat;
                    for(int j=0;j<lon;j++){
                        double phi=2*Math.PI*j/lon;
                        float x=(float)(Math.sin(theta)*Math.cos(phi));
                        float y=(float)Math.cos(theta);
                        float z=(float)(Math.sin(theta)*Math.sin(phi));
                        vlist.add(new float[]{x,y,z});
                    }
                }
                for(int i=0;i<=lat;i++){
                    for(int j=0;j<lon;j++){
                        int idx=i*lon+j;
                        int next=i*lon+(j+1)%lon;
                        elist.add(new int[]{idx,next});
                        if(i<lat) elist.add(new int[]{idx, idx+lon});
                    }
                }
                verts=vlist.toArray(new float[0][]);
                edges=elist.toArray(new int[0][]);
            }
        }

        void pauseSpin(){ running=false; }
        void resumeSpin(){ if(!running){ running=true; postInvalidateLoop(); } }

        void postInvalidateLoop(){
            postOnAnimation(new Runnable(){ public void run(){
                if(!dragging) yaw+=autoSpinSpeed;
                invalidate();
                if(running) postOnAnimation(this);
            }});
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev){
            switch(ev.getAction()){
                case MotionEvent.ACTION_DOWN: dragging=true; lastX=ev.getX(); lastY=ev.getY(); return true;
                case MotionEvent.ACTION_MOVE:
                    float dx=ev.getX()-lastX, dy=ev.getY()-lastY;
                    yaw+=dx*0.006f; pitch+=dy*0.006f;
                    pitch=Math.max(-1.4f,Math.min(1.4f,pitch));
                    lastX=ev.getX(); lastY=ev.getY();
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: dragging=false; return true;
            }
            return super.onTouchEvent(ev);
        }

        @Override
        protected void onDraw(Canvas cv){
            int w=getWidth(), h=getHeight();
            float cx=w/2f, cy=h/2f;
            float scale=Math.min(w,h)*0.30f;

            // faint circular grid rings for a "projection pad" feel
            for(int r=1;r<=4;r++){
                cv.drawCircle(cx,cy,scale*1.15f*r/4f,gridPaint);
            }
            // horizontal scan lines
            for(int y=0;y<h;y+=4){ cv.drawLine(0,y,w,y,scanPaint); }

            float cosY=(float)Math.cos(yaw), sinY=(float)Math.sin(yaw);
            float cosX=(float)Math.cos(pitch), sinX=(float)Math.sin(pitch);
            float[] sx=new float[verts.length], sy=new float[verts.length];
            for(int i=0;i<verts.length;i++){
                float x=verts[i][0], y=verts[i][1], z=verts[i][2];
                // rotate Y (yaw)
                float x1=x*cosY - z*sinY;
                float z1=x*sinY + z*cosY;
                // rotate X (pitch)
                float y2=y*cosX - z1*sinX;
                float z2=y*sinX + z1*cosX;
                float focal=4f;
                float persp=focal/(focal+z2);
                sx[i]=cx + x1*scale*persp;
                sy[i]=cy + y2*scale*persp;
            }
            for(int[] e:edges){
                float x1=sx[e[0]],y1=sy[e[0]],x2=sx[e[1]],y2=sy[e[1]];
                cv.drawLine(x1,y1,x2,y2,glowPaint);
                cv.drawLine(x1,y1,x2,y2,linePaint);
            }
        }
    }
}
