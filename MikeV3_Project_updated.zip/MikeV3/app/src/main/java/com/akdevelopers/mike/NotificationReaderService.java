package com.akdevelopers.mike;

import android.app.Notification;
import android.content.SharedPreferences;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.speech.tts.TextToSpeech;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Reads incoming WhatsApp / SMS notifications aloud using their own TextToSpeech
 * instance, so it works even if MainActivity is not open. Requires the user to grant
 * "Notification access" separately from the Accessibility permission (Android treats
 * reading notification content as a more sensitive permission).
 *
 * Turned on/off from Settings ("Read notifications aloud"). Only a small whitelist of
 * messaging apps is read, to avoid Mike narrating every game/ad notification on the phone.
 */
public class NotificationReaderService extends NotificationListenerService {

    static final Set<String> WHITELIST = new HashSet<>(Arrays.asList(
        "com.whatsapp", "com.whatsapp.w4b",
        "com.google.android.apps.messaging", // Google Messages
        "com.android.mms", "com.android.messaging",
        "com.samsung.android.messaging"
    ));

    TextToSpeech tts;
    boolean ttsReady=false;

    @Override
    public void onCreate(){
        super.onCreate();
        tts = new TextToSpeech(this, status -> {
            if(status==TextToSpeech.SUCCESS){
                ttsReady=true;
                SharedPreferences prefs=getSharedPreferences(SettingsActivity.PREFS_NAME, MODE_PRIVATE);
                tts.setSpeechRate(prefs.getInt(SettingsActivity.KEY_SPEECH_RATE,100)/100f);
            }
        });
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn){
        if(sbn==null) return;
        SharedPreferences prefs=getSharedPreferences(SettingsActivity.PREFS_NAME, MODE_PRIVATE);
        boolean enabled=prefs.getBoolean(SettingsActivity.KEY_READ_NOTIFICATIONS,false);
        if(!enabled || !ttsReady) return;

        String pkg=sbn.getPackageName();
        if(pkg==null || !WHITELIST.contains(pkg)) return;

        Notification n=sbn.getNotification();
        if(n==null) return;
        // Skip group-summary notifications ("3 new messages") to avoid double-reading.
        if((n.flags & Notification.FLAG_GROUP_SUMMARY)!=0) return;

        CharSequence titleCs = n.extras!=null ? n.extras.getCharSequence(Notification.EXTRA_TITLE) : null;
        CharSequence textCs = n.extras!=null ? n.extras.getCharSequence(Notification.EXTRA_TEXT) : null;
        String title = titleCs!=null ? titleCs.toString() : "";
        String text = textCs!=null ? textCs.toString() : "";
        if(title.isEmpty() && text.isEmpty()) return;

        String appName = pkg.contains("whatsapp") ? "WhatsApp" : "message";
        String toSpeak = title.isEmpty()
            ? ("New "+appName+": "+text)
            : ("New "+appName+" from "+title+": "+text);
        tts.speak(toSpeak, TextToSpeech.QUEUE_ADD, null, "mike_notif_"+sbn.getKey());
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn){ }

    @Override
    public void onDestroy(){
        if(tts!=null){ tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
