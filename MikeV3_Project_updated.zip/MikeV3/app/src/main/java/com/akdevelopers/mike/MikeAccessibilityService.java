package com.akdevelopers.mike;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityEvent;
import java.util.List;

public class MikeAccessibilityService extends AccessibilityService {
    static MikeAccessibilityService instance;
    @Override public void onServiceConnected(){ instance=this; }
    // Left as a no-op hook: WhatsApp's send-button click is handled on demand by
    // clickSendButton() a short delay after opening the chat, so we don't need to
    // process every accessibility event system-wide (that was leftover debug wiring).
    @Override
    public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){}
    static boolean tapText(AccessibilityNodeInfo node, String wanted){
        if(node==null) return false;
        CharSequence t=node.getText();
        if(t!=null && t.toString().equalsIgnoreCase(wanted)) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        CharSequence d=node.getContentDescription();
        if(d!=null && d.toString().equalsIgnoreCase(wanted)) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        for(int i=0;i<node.getChildCount();i++) if(tapText(node.getChild(i),wanted)) return true;
        return false;
    }
    boolean tap(String text){ return tapText(getRootInActiveWindow(), text); }

    static boolean longPressText(AccessibilityNodeInfo node, String wanted){
        if(node==null) return false;
        CharSequence t=node.getText();
        CharSequence d=node.getContentDescription();
        boolean matches=(t!=null && t.toString().equalsIgnoreCase(wanted)) || (d!=null && d.toString().equalsIgnoreCase(wanted));
        if(matches) return node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK);
        for(int i=0;i<node.getChildCount();i++) if(longPressText(node.getChild(i),wanted)) return true;
        return false;
    }
    boolean longPress(String text){ return longPressText(getRootInActiveWindow(), text); }

    boolean setTextInField(String text){
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null)return false;
        return setEditableText(root,text);
    }

    boolean setEditableText(AccessibilityNodeInfo node,String text){
        if(node==null)return false;

        if(node.isEditable()){
            android.os.Bundle args=new android.os.Bundle();
            args.putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            );

            if(node.performAction(
                AccessibilityNodeInfo.ACTION_SET_TEXT,
                args
            )) return true;
        }

        for(int i=0;i<node.getChildCount();i++){
            if(setEditableText(node.getChild(i),text)) return true;
        }

        return false;
    }

    boolean clickSendButton(){
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null)return false;
        return clickSend(root);
    }

    boolean clickSend(AccessibilityNodeInfo node){
        if(node==null)return false;

        CharSequence t=node.getText();
        CharSequence d=node.getContentDescription();
        CharSequence id=node.getViewIdResourceName();

        String text=t==null?"":t.toString().toLowerCase(java.util.Locale.ROOT);
        String desc=d==null?"":d.toString().toLowerCase(java.util.Locale.ROOT);
        String rid=id==null?"":id.toString().toLowerCase(java.util.Locale.ROOT);

        boolean looksLikeSend=
            text.equals("send") ||
            desc.equals("send") ||
            text.contains("send") ||
            desc.contains("send") ||
            rid.contains("send");

        if(looksLikeSend){
            if(node.isClickable() &&
               node.performAction(AccessibilityNodeInfo.ACTION_CLICK))
                return true;

            AccessibilityNodeInfo parent=node.getParent();

            if(parent!=null &&
               parent.isClickable() &&
               parent.performAction(AccessibilityNodeInfo.ACTION_CLICK))
                return true;
        }

        for(int i=0;i<node.getChildCount();i++){
            if(clickSend(node.getChild(i)))return true;
        }

        return false;
    }

}
