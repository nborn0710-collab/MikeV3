package com.akdevelopers.mike;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    CameraManager cameraManager; String cameraId; boolean flashOn=false; LinearLayout root; TextView status, heard, log, clock, battery, reactor; Button mic, control, settingsBtn; TextToSpeech tts; SpeechRecognizer sr; boolean listening=false;
    final ExecutorService exec=Executors.newSingleThreadExecutor();
    String pendingType="", pendingName="", pendingNumber="", pendingMessage="";
    String lastContactName="", lastContactNumber=""; // remembers who we last called/messaged, for follow-ups like "call him back"
    SharedPreferences prefs;
    boolean alwaysListen=false;   // "wake-word-lite" mode: keeps re-listening, only reacts to phrases starting with mike/hey mike
    boolean awaitingWake=false;   // true while a listening cycle was auto-restarted (not a manual tap)
    ObjectAnimator reactorPulse;
    final Handler tickHandler=new Handler(Looper.getMainLooper());
    final Runnable tick=new Runnable(){ public void run(){ updateHeader(); tickHandler.postDelayed(this,1000); } };

    TextView greetName;
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,int sp){ TextView v=new TextView(this); v.setText(s); v.setTextColor(Color.WHITE); v.setTextSize(sp); v.setTypeface(Typeface.DEFAULT,Typeface.NORMAL); v.setPadding(dp(8),dp(6),dp(8),dp(6)); return v; }
    String greetingWord(){
        int h=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if(h<12) return "Good morning";
        if(h<17) return "Good afternoon";
        if(h<21) return "Good evening";
        return "Good night";
    }
    Button quickBtn(String label){
        Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(12); b.setTextColor(Color.rgb(0,200,235)); b.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); b.setBackgroundResource(com.akdevelopers.mike.R.drawable.btn_outline); b.setPadding(0,0,0,0);
        return b;
    }
    void openMusic(){
        try{
            Intent i=new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_APP_MUSIC); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        }catch(Exception e){
            try{ Intent i2=getPackageManager().getLaunchIntentForPackage("com.spotify.music"); if(i2!=null){startActivity(i2);return;} }catch(Exception ignored){}
            speak("I could not find a music app to open.");
        }
    }
    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences(SettingsActivity.PREFS_NAME, MODE_PRIVATE); alwaysListen=prefs.getBoolean(SettingsActivity.KEY_ALWAYS_LISTEN,false); initFlashlight(); buildUI(); setupVoice(); requestPermissions(); root.setAlpha(0f); root.animate().alpha(1f).setDuration(420).start(); handleIncomingIntent(getIntent()); }
    @Override public void onNewIntent(Intent i){ super.onNewIntent(i); setIntent(i); handleIncomingIntent(i); }
    void handleIncomingIntent(Intent i){
        if(i==null) return;
        String cmd=i.getStringExtra("voice_command");
        if(cmd!=null && !cmd.trim().isEmpty()){
            final String fc=cmd;
            root.postDelayed(()->handle(fc),400); // small delay so TTS/UI are ready
            i.removeExtra("voice_command");
        }
    }
    @Override public void onResume(){ super.onResume(); alwaysListen=prefs.getBoolean(SettingsActivity.KEY_ALWAYS_LISTEN,false); tickHandler.post(tick); if(greetName!=null) greetName.setText(prefs.getString(SettingsActivity.KEY_USER_NAME,"Boss")); }
    @Override public void onPause(){ super.onPause(); tickHandler.removeCallbacks(tick); }
    void updateHeader(){
        if(clock==null||battery==null)return;
        clock.setText(new java.text.SimpleDateFormat("hh:mm a",Locale.ENGLISH).format(new Date()));
        try{
            android.os.BatteryManager bm=(android.os.BatteryManager)getSystemService(BATTERY_SERVICE);
            int p=bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY);
            battery.setText(p+"%");
        }catch(Exception e){ battery.setText(""); }
    }
    void startReactorPulse(){
        if(reactor==null)return;
        reactorPulse=ObjectAnimator.ofFloat(reactor,"alpha",0.55f,1f);
        reactorPulse.setDuration(1400); reactorPulse.setRepeatCount(ValueAnimator.INFINITE); reactorPulse.setRepeatMode(ValueAnimator.REVERSE);
        reactorPulse.setInterpolator(new AccelerateDecelerateInterpolator());
        reactorPulse.start();
    }
    void initFlashlight(){ try{ cameraManager=(CameraManager)getSystemService(CAMERA_SERVICE); for(String id:cameraManager.getCameraIdList()){ CameraCharacteristics cc=cameraManager.getCameraCharacteristics(id); Boolean f=cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE); Integer l=cc.get(CameraCharacteristics.LENS_FACING); if(Boolean.TRUE.equals(f)&&Integer.valueOf(CameraCharacteristics.LENS_FACING_BACK).equals(l)){ cameraId=id; break; } } }catch(Exception e){ cameraId=null; } }
    void buildUI(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(20),dp(22),dp(20)); root.setBackgroundResource(com.akdevelopers.mike.R.drawable.bg_root);

        // Header row: live clock on the left, battery percent on the right
        LinearLayout headerRow=new LinearLayout(this); headerRow.setOrientation(LinearLayout.HORIZONTAL); headerRow.setPadding(dp(4),0,dp(4),0);
        clock=tv("--:--",12); clock.setTextColor(Color.rgb(0,190,225)); clock.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); clock.setPadding(0,0,0,0); clock.setGravity(Gravity.START);
        battery=tv("--%",12); battery.setTextColor(Color.rgb(0,190,225)); battery.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); battery.setGravity(Gravity.END); battery.setPadding(0,0,0,0);
        headerRow.addView(clock,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        headerRow.addView(battery,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        root.addView(headerRow,new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView greetLine1=tv(greetingWord(),13); greetLine1.setTextColor(Color.rgb(0,190,225)); greetLine1.setGravity(Gravity.CENTER); greetLine1.setTypeface(Typeface.MONOSPACE,Typeface.NORMAL); greetLine1.setPadding(0,0,0,0); LinearLayout.LayoutParams g1lp=new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT); g1lp.topMargin=dp(4); root.addView(greetLine1,g1lp);
        greetName=tv(prefs.getString(SettingsActivity.KEY_USER_NAME,"Boss"),24); greetName.setTextColor(Color.rgb(0,225,255)); greetName.setGravity(Gravity.CENTER); greetName.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); greetName.setPadding(0,0,0,0); root.addView(greetName,new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT));

        // Reactor icon on a soft glowing halo
        FrameLayout glowWrap=new FrameLayout(this);
        View glow=new View(this); glow.setBackgroundResource(com.akdevelopers.mike.R.drawable.glow_circle);
        FrameLayout.LayoutParams glp=new FrameLayout.LayoutParams(dp(172),dp(172)); glp.gravity=Gravity.CENTER; glowWrap.addView(glow,glp);
        reactor=tv("◉",84); reactor.setTextColor(Color.rgb(0,220,255)); reactor.setGravity(Gravity.CENTER); reactor.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); reactor.setPadding(0,0,0,0);
        FrameLayout.LayoutParams rlp=new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT); rlp.gravity=Gravity.CENTER; glowWrap.addView(reactor,rlp);
        LinearLayout.LayoutParams glwp=new LinearLayout.LayoutParams(-1,dp(172)); glwp.topMargin=dp(8); glwp.bottomMargin=dp(4); root.addView(glowWrap,glwp);
        startReactorPulse();

        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER_HORIZONTAL); card.setPadding(dp(18),dp(16),dp(18),dp(16)); card.setBackgroundResource(com.akdevelopers.mike.R.drawable.bg);
        status=tv("[ SYSTEM READY ]",12); status.setTextColor(Color.rgb(0,210,255)); status.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); status.setGravity(Gravity.CENTER); card.addView(status,new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT));
        heard=tv("Say something to Mike",19); heard.setTypeface(Typeface.DEFAULT,Typeface.BOLD); heard.setGravity(Gravity.CENTER); LinearLayout.LayoutParams hlp=new LinearLayout.LayoutParams(-1,dp(84)); hlp.topMargin=dp(6); card.addView(heard,hlp);
        LinearLayout.LayoutParams cardLp=new LinearLayout.LayoutParams(-1,dp(158)); cardLp.topMargin=dp(4); root.addView(card,cardLp);

        // Quick-action shortcuts: Music, Weather, Apps
        LinearLayout quickRow=new LinearLayout(this); quickRow.setOrientation(LinearLayout.HORIZONTAL); quickRow.setWeightSum(3);
        Button qMusic=quickBtn("MUSIC"); qMusic.setOnClickListener(v->openMusic());
        Button qWeather=quickBtn("WEATHER"); qWeather.setOnClickListener(v->getWeather());
        Button qApps=quickBtn("APPS"); qApps.setOnClickListener(v->{ try{ startActivity(new Intent(Settings.ACTION_APPLICATION_SETTINGS)); }catch(Exception e){ speak("I could not open the apps list."); } });
        LinearLayout.LayoutParams q1=new LinearLayout.LayoutParams(0,dp(48),1); q1.rightMargin=dp(6);
        LinearLayout.LayoutParams q2=new LinearLayout.LayoutParams(0,dp(48),1); q2.leftMargin=dp(3); q2.rightMargin=dp(3);
        LinearLayout.LayoutParams q3=new LinearLayout.LayoutParams(0,dp(48),1); q3.leftMargin=dp(6);
        quickRow.addView(qMusic,q1); quickRow.addView(qWeather,q2); quickRow.addView(qApps,q3);
        LinearLayout.LayoutParams qrp=new LinearLayout.LayoutParams(-1,dp(48)); qrp.topMargin=dp(14); root.addView(quickRow,qrp);

        mic=new Button(this); mic.setText("[ TAP TO SPEAK ]"); mic.setTextSize(15); mic.setTextColor(Color.rgb(0,225,255)); mic.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); mic.setAllCaps(false); mic.setBackgroundResource(com.akdevelopers.mike.R.drawable.btn_primary); mic.setOnClickListener(v->listen()); LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(64)); mp.topMargin=dp(18); root.addView(mic,mp);
        control=new Button(this); control.setText("[ ENABLE APP CONTROL ]"); control.setAllCaps(false); control.setTextColor(Color.rgb(0,180,220)); control.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); control.setBackgroundResource(com.akdevelopers.mike.R.drawable.btn_outline); control.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(52)); cp.topMargin=dp(10); root.addView(control,cp);
        settingsBtn=new Button(this); settingsBtn.setText("[ SETTINGS ]"); settingsBtn.setAllCaps(false); settingsBtn.setTextColor(Color.rgb(0,180,220)); settingsBtn.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); settingsBtn.setBackgroundResource(com.akdevelopers.mike.R.drawable.btn_outline); settingsBtn.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class))); LinearLayout.LayoutParams sbp=new LinearLayout.LayoutParams(-1,dp(52)); sbp.topMargin=dp(10); root.addView(settingsBtn,sbp);
        Button testVol=new Button(this); testVol.setText("[ TEST VOL+ (NO VOICE) ]"); testVol.setAllCaps(false); testVol.setTextColor(Color.rgb(255,180,0)); testVol.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); testVol.setBackgroundResource(com.akdevelopers.mike.R.drawable.btn_test); testVol.setOnClickListener(v->adjustVolume(AudioManager.ADJUST_RAISE)); LinearLayout.LayoutParams tvp=new LinearLayout.LayoutParams(-1,dp(52)); tvp.topMargin=dp(10); root.addView(testVol,tvp);
        Button testVolDown=new Button(this); testVolDown.setText("[ TEST VOL- (NO VOICE) ]"); testVolDown.setAllCaps(false); testVolDown.setTextColor(Color.rgb(255,180,0)); testVolDown.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); testVolDown.setBackgroundResource(com.akdevelopers.mike.R.drawable.btn_test); testVolDown.setOnClickListener(v->adjustVolume(AudioManager.ADJUST_LOWER)); LinearLayout.LayoutParams tvdp=new LinearLayout.LayoutParams(-1,dp(52)); tvdp.topMargin=dp(10); root.addView(testVolDown,tvdp);
        log=tv("COMMANDS: APP | CALL | SMS | FLASH | SEARCH | TIME | BATTERY | WEATHER | CALC | VOLUME | ALARM | MUSIC",11); log.setTextColor(Color.rgb(0,150,190)); log.setTypeface(Typeface.MONOSPACE,Typeface.NORMAL); log.setGravity(Gravity.CENTER); LinearLayout.LayoutParams logLp=new LinearLayout.LayoutParams(-1,0,1); logLp.topMargin=dp(14); root.addView(log,logLp);

        ScrollView scroll=new ScrollView(this); scroll.setBackgroundResource(com.akdevelopers.mike.R.drawable.bg_root); scroll.addView(root,new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
    }
    void requestPermissions(){ ArrayList<String> p=new ArrayList<>(); if(Build.VERSION.SDK_INT>=23){ if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.RECORD_AUDIO); if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.READ_CONTACTS); if(checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.CALL_PHONE); if(checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.SEND_SMS); if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.POST_NOTIFICATIONS); } if(!p.isEmpty())requestPermissions(p.toArray(new String[0]),44); }
    void setupVoice(){
        tts=new TextToSpeech(this, s->{ tts.setLanguage(Locale.ENGLISH); float rate=prefs.getInt(SettingsActivity.KEY_SPEECH_RATE,100)/100f; tts.setSpeechRate(rate); });
        if(SpeechRecognizer.isRecognitionAvailable(this)) sr=SpeechRecognizer.createSpeechRecognizer(this);
        if(sr!=null) sr.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle b){ status.setText(alwaysListen?"LISTENING (ALWAYS ON)...":"LISTENING..."); if(reactor!=null)reactor.setTextColor(Color.rgb(80,255,160)); }
            public void onBeginningOfSpeech(){ }
            public void onRmsChanged(float r){}
            public void onBufferReceived(byte[] b){}
            public void onEndOfSpeech(){status.setText("PROCESSING..."); if(reactor!=null)reactor.setTextColor(Color.rgb(255,210,0));}
            public void onError(int e){
                listening=false; status.setText("READY"); mic.setText("TAP TO SPEAK"); if(reactor!=null)reactor.setTextColor(Color.rgb(0,220,255));
                if(alwaysListen){ restartAlwaysListening(); return; }
                speak("I couldn't understand that. Please try again.");
            }
            public void onResults(Bundle b){
                listening=false; status.setText("READY"); mic.setText("TAP TO SPEAK"); if(reactor!=null)reactor.setTextColor(Color.rgb(0,220,255));
                ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String raw=(a!=null&&!a.isEmpty())?a.get(0):null;
                if(alwaysListen){
                    // In always-listening mode, only react to phrases that start with the wake word.
                    if(raw!=null){
                        String low=raw.toLowerCase(Locale.ROOT).trim();
                        if(low.startsWith("hey mike")||low.startsWith("mike")||low.startsWith("ok mike")||low.startsWith("okay mike")){
                            handle(raw);
                        }
                    }
                    restartAlwaysListening();
                    return;
                }
                if(raw!=null) handle(raw);
            }
            public void onPartialResults(Bundle b){} public void onEvent(int x,Bundle b){}
        });
    }
    void restartAlwaysListening(){
        // Re-arms the recognizer automatically so the app keeps "waiting" for the wake word.
        if(!alwaysListen||sr==null)return;
        root.postDelayed(()->{ if(alwaysListen&&!listening) listen(); },600);
    }
    void listen(){ if(sr==null){speak("Speech recognition is not available on this phone.");return;} if(listening){sr.stopListening();return;} listening=true; mic.setText(alwaysListen?"LISTENING (ALWAYS ON)...":"LISTENING..."); Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-IN"); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"en-IN"); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false); if(Build.VERSION.SDK_INT>=34){i.putExtra("android.speech.extra.ENABLE_LANGUAGE_DETECTION",true); i.putExtra("android.speech.extra.LANGUAGE_DETECTION_ALLOWED_LANGUAGES",new String[]{"en-IN","hi-IN","en-US"});} sr.startListening(i); }
    void speak(String s){ if(s==null||s.trim().isEmpty())return; heard.setText(s); if(s.matches(".*[\\u0900-\\u097F].*"))tts.setLanguage(new Locale("hi","IN")); else tts.setLanguage(Locale.ENGLISH); tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"mike"); }
    String n(String s){ String x=s.toLowerCase(Locale.ROOT).replaceAll("[!?.,]"," ").replaceAll("\\s+"," ").trim(); while(x.matches("^(hey|okay|ok|mike)\\s+.*")) x=x.replaceFirst("^(hey|okay|ok|mike)\\s+",""); x=x.replaceFirst("\\s+(mike)$","").trim(); return x; }
    void mediaKey(int keyCode){
        try{
            AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);
            long now=android.os.SystemClock.uptimeMillis();
            android.view.KeyEvent down=new android.view.KeyEvent(now,now,android.view.KeyEvent.ACTION_DOWN,keyCode,0);
            android.view.KeyEvent up=new android.view.KeyEvent(now,now,android.view.KeyEvent.ACTION_UP,keyCode,0);
            am.dispatchMediaKeyEvent(down);
            am.dispatchMediaKeyEvent(up);
        }catch(Exception e){ /* no active media session to control; silently ignore */ }
    }
    void adjustVolume(int direction){ adjustVolume(direction,0); }
    void adjustVolume(int direction,long delayMs){
        Runnable r=()->{
            try{
                AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);
                int max=am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                int before=am.getStreamVolume(AudioManager.STREAM_MUSIC);
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC,direction,AudioManager.FLAG_SHOW_UI|AudioManager.FLAG_PLAY_SOUND);
                int after=am.getStreamVolume(AudioManager.STREAM_MUSIC);
                if(direction==AudioManager.ADJUST_MUTE){speak("Muted. Volume was "+before+" of "+max+".");return;}
                if(direction==AudioManager.ADJUST_UNMUTE){speak("Unmuted. Volume is "+after+" of "+max+".");return;}
                speak("Volume changed from "+before+" to "+after+" out of "+max+".");
            }catch(SecurityException se){ speak("I do not have permission to change the volume."); }
            catch(Exception e){ speak("I could not change the volume. Error: "+e.getClass().getSimpleName()); }
        };
        if(delayMs<=0) r.run(); else root.postDelayed(r,delayMs);
    }
    void setVolumePercent(String s){ try{ int pct=Integer.parseInt(s.replaceAll("[^0-9]","")); pct=Math.max(0,Math.min(100,pct)); AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE); int max=am.getStreamMaxVolume(AudioManager.STREAM_MUSIC); int level=Math.round(max*pct/100f); am.setStreamVolume(AudioManager.STREAM_MUSIC,level,AudioManager.FLAG_SHOW_UI); speak("Volume set to "+pct+" percent."); }catch(Exception e){ speak("I did not understand that volume level."); } }
    void setFlashlight(boolean on){ try{ if(cameraManager==null||cameraId==null){ speak("Flashlight is not available."); return; } cameraManager.setTorchMode(cameraId,on); flashOn=on; speak(on?"Turning the flashlight on.":"Turning the flashlight off."); }catch(Exception e){ speak("I could not control the flashlight."); } }
    void getWeatherCity(String c){ String city=prefs.getString(SettingsActivity.KEY_CITY,"Pune"); int p=c.indexOf("weather in "); if(p>=0){ city=c.substring(p+11).trim(); } else if(c.startsWith("weather ")){ String rest=c.substring(8).trim(); if(!rest.isEmpty()&&!rest.equals("weather"))city=rest; } final String target=city; exec.execute(()->{ try{ java.net.URL g=new java.net.URL("https://geocoding-api.open-meteo.com/v1/search?name="+Uri.encode(target)+"&count=1&language=en&format=json"); java.net.HttpURLConnection gh=(java.net.HttpURLConnection)g.openConnection(); gh.setConnectTimeout(10000); gh.setReadTimeout(10000); java.io.BufferedReader gr=new java.io.BufferedReader(new java.io.InputStreamReader(gh.getInputStream())); StringBuilder gb=new StringBuilder(); String gz; while((gz=gr.readLine())!=null)gb.append(gz); gr.close(); org.json.JSONArray ga=new org.json.JSONObject(gb.toString()).getJSONArray("results"); org.json.JSONObject place=ga.getJSONObject(0); double lat=place.getDouble("latitude"),lon=place.getDouble("longitude"); String name=place.getString("name"); java.net.URL u=new java.net.URL("https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+"&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=auto"); java.net.HttpURLConnection h=(java.net.HttpURLConnection)u.openConnection(); h.setConnectTimeout(10000); h.setReadTimeout(10000); java.io.BufferedReader r=new java.io.BufferedReader(new java.io.InputStreamReader(h.getInputStream())); StringBuilder b=new StringBuilder(); String z; while((z=r.readLine())!=null)b.append(z); r.close(); org.json.JSONObject o=new org.json.JSONObject(b.toString()).getJSONObject("current"); double t=o.getDouble("temperature_2m"); int hum=o.getInt("relative_humidity_2m"); double wind=o.getDouble("wind_speed_10m"); int code=o.getInt("weather_code"); String condition=weatherCondition(code); final String ans=name+" weather: "+Math.round(t)+" degrees Celsius, "+condition+", humidity "+hum+" percent, wind "+Math.round(wind)+" kilometers per hour."; cacheWeather(ans); runOnUiThread(()->speak(ans)); }catch(Exception e){ runOnUiThread(()->speakCachedOrFail(target)); } }); }
    void getWeather(){ getWeatherCity("weather"); }
    String weatherCondition(int c){ if(c==0)return "clear sky"; if(c<=3)return "partly cloudy"; if(c<=48)return "foggy"; if(c<=57)return "drizzling"; if(c<=67)return "rainy"; if(c<=77)return "snowy"; if(c<=82)return "rain showers"; return "thunderstorms"; }
    // --- Offline fallback: remembers the last successful weather reading so Mike can still
    // answer (with a disclaimer) when there is no internet connection. ---
    void cacheWeather(String text){ prefs.edit().putString(SettingsActivity.KEY_LAST_WEATHER_TEXT,text).putLong(SettingsActivity.KEY_LAST_WEATHER_TIME,System.currentTimeMillis()).apply(); }
    void speakCachedOrFail(String target){
        String cached=prefs.getString(SettingsActivity.KEY_LAST_WEATHER_TEXT,null);
        long when=prefs.getLong(SettingsActivity.KEY_LAST_WEATHER_TIME,0);
        if(cached!=null&&when>0){
            long mins=(System.currentTimeMillis()-when)/60000;
            String age=mins<1?"just now":mins<60?(mins+" minutes ago"):((mins/60)+" hours ago");
            speak("I'm offline, so here is the last weather I have, from "+age+". "+cached);
        } else {
            speak("I could not find weather for "+target+" right now. Please check your internet connection.");
        }
    }
    void handle(String raw){ heard.setText(raw); log.setText("Last command: "+raw); String c=n(raw); status.setText("[ PROCESSING ]"); if(c.equals("stop")||c.equals("exit")||c.equals("goodbye")){speak("Okay. Goodbye.");return;} if(c.contains("who made you")||c.contains("who developed you")||c.contains("who created you")){speak("I was made by A.K DEVELOPERS.");return;} if(c.equals("hello")||c.equals("hi")||c.equals("hey")||c.equals("good morning")||c.equals("good evening")||c.equals("good morning mike")||c.equals("good evening mike")){speak("Hello. How can I help you?");return;} if(c.contains("time")){speak("The time is "+new java.text.SimpleDateFormat("hh:mm a",Locale.ENGLISH).format(new Date()));return;} if(c.contains("date")||c.equals("today")){speak("Today is "+new java.text.SimpleDateFormat("dd MMMM yyyy",Locale.ENGLISH).format(new Date()));return;} if(c.contains("battery")){android.os.BatteryManager bm=(android.os.BatteryManager)getSystemService(BATTERY_SERVICE);int p=bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY);speak("Battery is "+p+" percent.");return;} if(c.contains("flashlight")||c.contains("torch")){setFlashlight(!c.contains("off"));return;} if(c.equals("open settings")||c.equals("mike settings")||c.equals("settings")){startActivity(new Intent(this,SettingsActivity.class));speak("Opening settings.");return;} if(c.contains("hologram")){startActivity(new Intent(this,HologramActivity.class));speak("Opening hologram mode.");return;} if(c.startsWith("set volume to ")){setVolumePercent(c.substring(15));return;} if(c.contains("mute")&&!c.contains("unmute")){adjustVolume(AudioManager.ADJUST_MUTE,500);return;} if(c.contains("unmute")){adjustVolume(AudioManager.ADJUST_UNMUTE,500);return;} if(c.equals("silent mode")||c.equals("silent")){adjustVolume(AudioManager.ADJUST_MUTE,500);return;} if(c.equals("pause")||c.equals("pause music")||c.equals("pause song")){mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PAUSE);speak("Pausing.");return;} if(c.equals("play")||c.equals("play music")||c.equals("resume")||c.equals("resume music")||c.equals("unpause")){mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PLAY);speak("Playing.");return;} if(c.equals("stop music")||c.equals("stop song")){mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_STOP);speak("Stopped.");return;} if(c.contains("next song")||c.contains("next track")||c.equals("skip")||c.equals("skip song")){mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT);speak("Next track.");return;} if(c.contains("previous song")||c.contains("last song")||c.contains("play last")||c.equals("go back song")){mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS);speak("Previous track.");return;} if(c.contains("volume")||c.contains("louder")||c.contains("quieter")){ boolean up=c.contains("up")||c.contains("increase")||c.contains("raise")||c.contains("louder")||c.contains("more"); boolean down=c.contains("down")||c.contains("decrease")||c.contains("lower")||c.contains("quieter")||c.contains("reduce")||c.contains("less"); if(up&&!down){adjustVolume(AudioManager.ADJUST_RAISE,500);return;} if(down&&!up){adjustVolume(AudioManager.ADJUST_LOWER,500);return;} } if(c.equals("open notifications")||c.equals("show notifications")){if(MikeAccessibilityService.instance!=null){MikeAccessibilityService.instance.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS);speak("Opening notifications.");}else speak("Please enable App Control first.");return;} if(c.equals("quick settings")||c.equals("open quick settings")){if(MikeAccessibilityService.instance!=null){MikeAccessibilityService.instance.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS);speak("Opening quick settings.");}else speak("Please enable App Control first.");return;} if(c.startsWith("long press ")){String x=c.substring(11).trim();if(MikeAccessibilityService.instance!=null&&MikeAccessibilityService.instance.longPress(x))speak("Done.");else speak("I could not long-press that item.");return;} if(c.startsWith("set alarm")||c.startsWith("set an alarm")||c.startsWith("wake me up")||c.startsWith("alarm for")||c.startsWith("set a reminder")){ int[] t=parseTimeAfter(c,"for","at"); if(t==null){speak("Please tell me a time, like set alarm for 7 am.");return;} setAlarm(t[0],t[1],"Mike alarm"); return; } if(c.startsWith("remind me to ")){ String rest=c.substring(13).trim(); int atIdx=rest.lastIndexOf(" at "); String msg = atIdx>=0? rest.substring(0,atIdx).trim() : rest.trim(); int[] t=parseTimeAfter(c,"at"); if(t==null){speak("Please tell me a time, like remind me to call mummy at 5 pm.");return;} setAlarm(t[0],t[1],msg.isEmpty()?"Mike reminder":msg); return; }
        // --- Follow-up / context commands: "call him back", "usko message karo ...", etc. ---
        if(c.contains("call")){
            String rest=c.replaceFirst(".*\\bcall\\b","").trim();
            if(isFollowupTarget(rest)){
                if(lastContactName.isEmpty()){speak("I don't have anyone to call yet. Say a name first, like call Rahul.");return;}
                doContact("call",lastContactName,"");
                return;
            }
        }
        String[][] followupMsgTriggers={
            {"reply ","sms"},{"usko bolo ","sms"},{"unhe bolo ","sms"},{"unko bolo ","sms"},
            {"usko likho ","sms"},{"unhe likho ","sms"},{"usko message karo ","sms"},{"unhe message karo ","sms"},
            {"tell him ","sms"},{"tell her ","sms"},{"tell them ","sms"},
            {"usko whatsapp karo ","whatsapp"},{"unhe whatsapp karo ","whatsapp"},
            {"whatsapp him saying ","whatsapp"},{"whatsapp her saying ","whatsapp"}
        };
        for(String[] tr:followupMsgTriggers){
            if(c.startsWith(tr[0])){
                String msg=c.substring(tr[0].length()).trim();
                if(lastContactName.isEmpty()){speak("I don't know who you mean. Say a name first.");return;}
                if(msg.isEmpty()){speak("What should I say?");return;}
                doContact(tr[1],lastContactName,msg);
                return;
            }
        } if(c.startsWith("youtube search ")){open("https://www.youtube.com/results?search_query="+Uri.encode(c.substring(15)),"Searching YouTube.");return;} if(c.startsWith("search youtube for ")){open("https://www.youtube.com/results?search_query="+Uri.encode(c.substring(19)),"Searching YouTube.");return;} if(c.startsWith("search for ")){open("https://www.google.com/search?q="+Uri.encode(c.substring(11)),"Searching Google.");return;} if(c.startsWith("search ")){open("https://www.google.com/search?q="+Uri.encode(c.substring(7)),"Searching Google.");return;} if(c.startsWith("google ")){open("https://www.google.com/search?q="+Uri.encode(c.substring(7)),"Searching Google.");return;} if(c.contains("weather")){getWeatherCity(c);return;} if(c.startsWith("calculate ")||c.startsWith("what is ")||c.startsWith("how much is ")||c.startsWith("solve ")){try{String x=c.replaceFirst("^(calculate|what is|how much is|solve) ","");x=x.replace("plus","+").replace("minus","-").replace("times","*").replace("multiplied by","*").replace("divided by","/").replace(" ","");double v=eval(x);speak("The answer is "+(v==(long)v?Long.toString((long)v):Double.toString(v)));}catch(Exception e){speak("I could not calculate this expression.");}return;} if(c.startsWith("call ")||c.contains(" call ")){String name=c.replaceFirst(".*\\bcall ","").replace(" please","").trim();doContact("call",name,"");return;} if(c.startsWith("whatsapp message ")||c.startsWith("send whatsapp message ")||c.startsWith("whatsapp ")){String rest=c.replaceFirst("^(send whatsapp message|whatsapp message|whatsapp) ","").trim();String[] z=rest.split("\\b(saying|that|says|bolo|likho)\\b",2);if(z.length<2){speak("Say the contact name and message, for example: WhatsApp message Rahul saying hello.");return;}doContact("whatsapp",z[0].trim(),z[1].trim());return;} if(c.startsWith("message ")||c.startsWith("text ")||c.contains(" message ")){String rest=c.replaceFirst(".*\\b(message|text) ","").trim();String[] z=rest.split("\\b(saying|that|says|bolo|likho)\\b",2);if(z.length<2){speak("Say the contact name and message, for example: message Rahul saying hello.");return;}doContact("sms",z[0].trim(),z[1].trim());return;} if(c.startsWith("open ")||c.startsWith("launch ")||c.startsWith("start ")){String app=c.replaceFirst("^(open|launch|start) ","").trim();if(app.endsWith(" app"))app=app.substring(0,app.length()-4).trim();if(openApp(app))return;} if(c.equals("go home")||c.equals("home")||c.equals("take me home")){if(MikeAccessibilityService.instance!=null){MikeAccessibilityService.instance.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME);speak("Going home.");}else speak("Please enable App Control first.");return;} if(c.equals("go back")||c.equals("back")){if(MikeAccessibilityService.instance!=null){MikeAccessibilityService.instance.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK);speak("Going back.");}else speak("Please enable App Control first.");return;} if(c.equals("recent apps")||c.equals("show recent apps")){if(MikeAccessibilityService.instance!=null){MikeAccessibilityService.instance.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS);speak("Opening recent apps.");}else speak("Please enable App Control first.");return;} if(c.startsWith("tap ")){String x=c.substring(4).trim();if(MikeAccessibilityService.instance!=null&&MikeAccessibilityService.instance.tap(x))speak("Done.");else speak("I could not tap that item.");return;} if(c.equals("scroll down")||c.equals("scroll up")||c.equals("scroll")){if(MikeAccessibilityService.instance!=null){boolean down=!c.equals("scroll up");AccessibilityNodeInfo r=MikeAccessibilityService.instance.getRootInActiveWindow();if(r!=null)scroll(r,down);speak(down?"Scrolling down.":"Scrolling up.");}else speak("Please enable App Control first.");return;} if(c.equals("what can you do")||c.equals("help")){speak("I can open apps, search, check time and battery, control navigation, calculate, and help with calls and messages.");return;} speak("I did not understand that. Try saying open YouTube, search Google, check battery, go home, or scroll down.");}    boolean isFollowupTarget(String s){
        String x=" "+s.trim()+" ";
        x=x.replaceAll("\\b(please|karo|kar do|wapas|again|back|phir se|dobara|to him|to her|to them)\\b"," ");
        x=x.replaceAll("\\s+"," ").trim();
        if(x.isEmpty()) return true;
        switch(x){
            case "him": case "her": case "them": case "usko": case "use": case "unhe": case "unko":
            case "uske": case "ussey": case "usse": case "uska": case "uski": case "back": case "again":
                return true;
            default: return false;
        }
    }
    int[] parseTimeAfter(String c,String... keywords){
        for(String kw:keywords){
            int idx=c.lastIndexOf(kw+" ");
            if(idx<0) continue;
            String rest=c.substring(idx+kw.length()+1).trim();
            java.util.regex.Matcher mt=java.util.regex.Pattern.compile("^(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?").matcher(rest);
            if(mt.find()){
                int hh=Integer.parseInt(mt.group(1));
                int mm=mt.group(2)!=null?Integer.parseInt(mt.group(2)):0;
                String ap=mt.group(3);
                if(hh>23||mm>59) continue;
                if(ap!=null){
                    if(ap.equals("pm")&&hh<12) hh+=12;
                    if(ap.equals("am")&&hh==12) hh=0;
                }
                return new int[]{hh,mm};
            }
        }
        return null;
    }
    void setAlarm(int hour,int minute,String label){
        int h12=hour%12; if(h12==0)h12=12; String ampm=hour<12?"AM":"PM";
        String timeStr=h12+":"+String.format(Locale.ENGLISH,"%02d",minute)+" "+ampm;
        try{
            Intent i=new Intent(android.provider.AlarmClock.ACTION_SET_ALARM);
            i.putExtra(android.provider.AlarmClock.EXTRA_HOUR,hour);
            i.putExtra(android.provider.AlarmClock.EXTRA_MINUTES,minute);
            i.putExtra(android.provider.AlarmClock.EXTRA_MESSAGE,label);
            i.putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI,true);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            speak("Alarm set for "+timeStr+(label.equals("Mike alarm")?".":" to "+label+"."));
        }catch(Exception silentFail){
            // Some clock apps reject a silent (SKIP_UI) alarm request. Retry by opening
            // the Clock app's own "set alarm" screen so the user can confirm with one tap.
            try{
                Intent i2=new Intent(android.provider.AlarmClock.ACTION_SET_ALARM);
                i2.putExtra(android.provider.AlarmClock.EXTRA_HOUR,hour);
                i2.putExtra(android.provider.AlarmClock.EXTRA_MINUTES,minute);
                i2.putExtra(android.provider.AlarmClock.EXTRA_MESSAGE,label);
                i2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i2);
                speak("Opening your clock app to confirm the alarm for "+timeStr+".");
            }catch(Exception e2){
                speak("I could not set the alarm. Error: "+e2.getClass().getSimpleName()+". Your clock app may not support this.");
            }
        }
    }
    void openTermuxTorch(String c){try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("termux://torch"));startActivity(i);speak(c.contains("off")?"Turning the flashlight off.":"Turning the flashlight on.");}catch(Exception e){speak("Flashlight control needs Termux API.");}}
    void open(String u,String msg){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));speak(msg);}catch(Exception e){speak("I couldn't open that.");}}
    boolean openApp(String wanted){String w=wanted.toLowerCase(Locale.ROOT).trim();PackageManager pm=getPackageManager();Intent q=new Intent(Intent.ACTION_MAIN,null);q.addCategory(Intent.CATEGORY_LAUNCHER);List<android.content.pm.ResolveInfo> apps=pm.queryIntentActivities(q,0);for(android.content.pm.ResolveInfo r:apps){String label=r.loadLabel(pm).toString();String l=label.toLowerCase(Locale.ROOT);if(l.equals(w)||l.contains(w)||w.contains(l)){Intent i=pm.getLaunchIntentForPackage(r.activityInfo.packageName);if(i!=null){startActivity(i);speak("Opening "+label+".");return true;}}}speak("App not found: "+wanted);return true;}    void doContact(String type,String name,String msg){
        if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
            speak("Contacts permission is required.");
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},44);
            return;
        }

        String[] f=find(name);

        if(f==null){
            speak("I couldn't find that contact.");
            return;
        }

        pendingType=type;
        pendingName=f[0];
        pendingNumber=f[1];
        pendingMessage=msg;
        lastContactName=f[0];
        lastContactNumber=f[1];

        if(type.equals("call"))
            speak("Call "+pendingName+"? Please confirm on screen.");
        else if(type.equals("whatsapp"))
            speak("Send this WhatsApp message to "+pendingName+": "+pendingMessage+"? Please confirm on screen.");
        else
            speak("Send this message to "+pendingName+": "+pendingMessage+"? Please confirm on screen.");

        String dialogMessage;

        if(type.equals("call"))
            dialogMessage="Call "+pendingName+"?";
        else if(type.equals("whatsapp"))
            dialogMessage="WhatsApp to "+pendingName+":\\n\\n"+pendingMessage;
        else
            dialogMessage="Send to "+pendingName+":\\n\\n"+pendingMessage;

        new AlertDialog.Builder(this)
            .setTitle("Confirm action")
            .setMessage(dialogMessage)
            .setNegativeButton("Cancel",(d,w)->speak("Cancelled."))
            .setPositiveButton("Confirm",(d,w)->executePending())
            .show();
    }

    String[] find(String wanted){
    Cursor c=null;
    try{
        c=getContentResolver().query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            new String[]{
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            },
            null,null,null
        );

        if(c==null)return null;

        String w=normalizeContactName(wanted);
        String[] best=null;
        int bestScore=0;

        while(c.moveToNext()){
            String contact=c.getString(0);
            String number=c.getString(1);
            String n=normalizeContactName(contact);

            if(n.equals(w))
                return new String[]{contact,number};

            int score=contactMatchScore(w,n);

            if(score>bestScore){
                bestScore=score;
                best=new String[]{contact,number};
            }
        }

        if(bestScore>=65)return best;

    }finally{
        if(c!=null)c.close();
    }
    return null;
}

String normalizeContactName(String s){
    if(s==null)return "";
    return s.toLowerCase(Locale.ROOT)
            .replaceAll("[^a-z0-9]","");
}

int contactMatchScore(String wanted,String contact){
    if(wanted.isEmpty()||contact.isEmpty())return 0;
    if(contact.contains(wanted)||wanted.contains(contact))return 90;

    int distance=levenshtein(wanted,contact);
    int max=Math.max(wanted.length(),contact.length());

    if(max==0)return 0;

    int score=(int)(100.0*(max-distance)/max);

    return score;
}

int levenshtein(String a,String b){
    int[] prev=new int[b.length()+1];
    int[] cur=new int[b.length()+1];

    for(int j=0;j<=b.length();j++)prev[j]=j;

    for(int i=1;i<=a.length();i++){
        cur[0]=i;

        for(int j=1;j<=b.length();j++){
            int cost=a.charAt(i-1)==b.charAt(j-1)?0:1;

            cur[j]=Math.min(
                Math.min(cur[j-1]+1,prev[j]+1),
                prev[j-1]+cost
            );
        }

        int[] temp=prev;
        prev=cur;
        cur=temp;
    }

    return prev[b.length()];
}
    void executePending(){
        try{
            if(pendingType.equals("call")){
                Intent i=new Intent(
                    Intent.ACTION_CALL,
                    Uri.parse("tel:"+pendingNumber)
                );
                startActivity(i);
                speak("Calling "+pendingName+".");
            }
            else if(pendingType.equals("whatsapp")){
                String digits=pendingNumber.replaceAll("[^0-9]","");

                if(digits.startsWith("0"))
                    digits=digits.substring(1);

                if(digits.length()==10)
                    digits="91"+digits;

                Intent i=new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/"+digits+"?text="+Uri.encode(pendingMessage))
                );

                i.setPackage("com.whatsapp");
                startActivity(i);

                speak("Opening WhatsApp for "+pendingName+".");

                final String forWhom=pendingName;
                final int[] attemptsLeft={7}; // retry roughly every 700ms, up to ~5 seconds total
                android.os.Handler h=new android.os.Handler();
                Runnable[] tryClick=new Runnable[1];
                tryClick[0]=()->{
                    if(MikeAccessibilityService.instance!=null && MikeAccessibilityService.instance.clickSendButton()){
                        speak("WhatsApp message sent to "+forWhom+".");
                        return;
                    }
                    attemptsLeft[0]--;
                    if(attemptsLeft[0]>0){
                        h.postDelayed(tryClick[0],700);
                    } else {
                        speak("WhatsApp opened, but I could not find the Send button. Please tap Send manually.");
                    }
                };
                h.postDelayed(tryClick[0],1500);
            }
            else{
                android.telephony.SmsManager.getDefault().sendTextMessage(
                    pendingNumber,
                    null,
                    pendingMessage,
                    null,
                    null
                );
                speak("Message sent to "+pendingName+".");
            }
        }
        catch(SecurityException e){
            speak("Please allow the required phone permission.");
        }
        catch(Exception e){
            speak("I couldn't complete that action.");
        }
    }

    double eval(String s){return new Object(){int p=-1,c;void next(){c=++p<s.length()?s.charAt(p):-1;}double parse(){next();double x=expr();if(p<s.length())throw new RuntimeException();return x;}double expr(){double x=term();while(c=='+'||c=='-'){int o=c;next();double y=term();x=o=='+'?x+y:x-y;}return x;}double term(){double x=factor();while(c=='*'||c=='/'){int o=c;next();double y=factor();x=o=='*'?x*y:x/y;}return x;}double factor(){if(c=='+'){next();return factor();}if(c=='-'){next();return -factor();}if(c=='('){next();double x=expr();if(c!=')')throw new RuntimeException();next();return x;}StringBuilder b=new StringBuilder();while((c>='0'&&c<='9')||c=='.'){b.append((char)c);next();}if(b.length()==0)throw new RuntimeException();return Double.parseDouble(b.toString());}}.parse();}
    void scroll(AccessibilityNodeInfo n,boolean down){if(n==null)return; if(n.isScrollable()){n.performAction(down?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);return;}for(int i=0;i<n.getChildCount();i++)scroll(n.getChild(i),down);}
}
