package com.akdevelopers.mike;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Simple settings screen backed by SharedPreferences ("mike_prefs").
 * Lets the user set a default city for weather, speech rate for TTS,
 * and toggle "always listening" (wake-word-lite) mode.
 *
 * Other classes read these same keys via Prefs.* helper methods below.
 */
public class SettingsActivity extends Activity {

    public static final String PREFS_NAME = "mike_prefs";
    public static final String KEY_CITY = "default_city";
    public static final String KEY_SPEECH_RATE = "speech_rate"; // stored as int 50-200 (percent)
    public static final String KEY_ALWAYS_LISTEN = "always_listen";
    public static final String KEY_LAST_WEATHER_TEXT = "last_weather_text";
    public static final String KEY_LAST_WEATHER_TIME = "last_weather_time";
    public static final String KEY_USER_NAME = "user_name";
    public static final String KEY_READ_NOTIFICATIONS = "read_notifications";
    public static final String KEY_HANDSFREE = "handsfree_mode";

    EditText cityInput;
    SeekBar rateSeek;
    TextView rateLabel;

    int dp(int x){ return (int)(x*getResources().getDisplayMetrics().density+.5f); }

    TextView label(String s){
        TextView t=new TextView(this);
        t.setText(s);
        t.setTextColor(Color.rgb(0,210,255));
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        t.setTextSize(14);
        t.setPadding(0, dp(18), 0, dp(6));
        return t;
    }

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(22), dp(22), dp(22));
        root.setBackgroundColor(Color.rgb(2,7,13));

        TextView title = new TextView(this);
        title.setText("MIKE SETTINGS");
        title.setTextColor(Color.rgb(0,225,255));
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        // Default city
        root.addView(label("Default city for weather"));
        cityInput = new EditText(this);
        cityInput.setText(prefs.getString(KEY_CITY, "Pune"));
        cityInput.setTextColor(Color.WHITE);
        cityInput.setHintTextColor(Color.GRAY);
        cityInput.setHint("e.g. Pune, Mumbai, Delhi");
        root.addView(cityInput);

        // User's display name (used in the "Good morning, ___" greeting)
        root.addView(label("Your name (for the greeting)"));
        EditText nameInput = new EditText(this);
        nameInput.setText(prefs.getString(KEY_USER_NAME, "Boss"));
        nameInput.setTextColor(Color.WHITE);
        nameInput.setHintTextColor(Color.GRAY);
        nameInput.setHint("e.g. Boss, Rahul, Sir");
        root.addView(nameInput);

        // Speech rate
        int rate = prefs.getInt(KEY_SPEECH_RATE, 100);
        rateLabel = label("Speech rate: " + rate + "%");
        root.addView(rateLabel);
        rateSeek = new SeekBar(this);
        rateSeek.setMax(150); // maps to 50-200%
        rateSeek.setProgress(rate - 50);
        rateSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s, int p, boolean u){
                rateLabel.setText("Speech rate: " + (p+50) + "%");
            }
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        });
        root.addView(rateSeek);

        // Always listening toggle
        boolean alwaysListen = prefs.getBoolean(KEY_ALWAYS_LISTEN, false);
        Button listenToggle = new Button(this);
        listenToggle.setAllCaps(false);
        listenToggle.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        listenToggle.setText(alwaysListen ? "[ ALWAYS LISTENING: ON ]" : "[ ALWAYS LISTENING: OFF ]");
        listenToggle.setTextColor(Color.rgb(0,225,255));
        listenToggle.setOnClickListener(v -> {
            SharedPreferences p = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean cur = p.getBoolean(KEY_ALWAYS_LISTEN, false);
            boolean next = !cur;
            p.edit().putBoolean(KEY_ALWAYS_LISTEN, next).apply();
            listenToggle.setText(next ? "[ ALWAYS LISTENING: ON ]" : "[ ALWAYS LISTENING: OFF ]");
            Toast.makeText(this, next
                ? "Mike will keep listening for \"Hey Mike\" while the app is open."
                : "Always listening turned off.", Toast.LENGTH_LONG).show();
        });
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        tp.topMargin = dp(24);
        root.addView(listenToggle, tp);

        TextView note = new TextView(this);
        note.setText("When on, tap TAP TO SPEAK once to start; Mike will keep re-listening and only respond to phrases starting with \"Hey Mike\" or \"Mike\".");
        note.setTextColor(Color.rgb(0,150,190));
        note.setTextSize(11);
        note.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        np.topMargin = dp(8);
        root.addView(note, np);

        // Read notifications aloud (WhatsApp / SMS)
        boolean readNotif = prefs.getBoolean(KEY_READ_NOTIFICATIONS, false);
        Button notifToggle = new Button(this);
        notifToggle.setAllCaps(false);
        notifToggle.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        notifToggle.setText(readNotif ? "[ READ NOTIFICATIONS: ON ]" : "[ READ NOTIFICATIONS: OFF ]");
        notifToggle.setTextColor(Color.rgb(0,225,255));
        notifToggle.setOnClickListener(v -> {
            SharedPreferences p = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean cur = p.getBoolean(KEY_READ_NOTIFICATIONS, false);
            boolean next = !cur;
            p.edit().putBoolean(KEY_READ_NOTIFICATIONS, next).apply();
            notifToggle.setText(next ? "[ READ NOTIFICATIONS: ON ]" : "[ READ NOTIFICATIONS: OFF ]");
            Toast.makeText(this, next
                ? "Mike will read new WhatsApp/SMS notifications aloud (needs Notification access below)."
                : "Notification reading turned off.", Toast.LENGTH_LONG).show();
        });
        LinearLayout.LayoutParams ntp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        ntp.topMargin = dp(20);
        root.addView(notifToggle, ntp);

        Button notifAccess = new Button(this);
        notifAccess.setAllCaps(false);
        notifAccess.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        notifAccess.setText("[ ENABLE NOTIFICATION ACCESS ]");
        notifAccess.setTextColor(Color.rgb(0,180,220));
        notifAccess.setOnClickListener(v -> startActivity(new android.content.Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));
        LinearLayout.LayoutParams nap = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        nap.topMargin = dp(10);
        root.addView(notifAccess, nap);

        TextView notifNote = new TextView(this);
        notifNote.setText("Android requires a separate permission for reading notification content. Tap the button above, find MIKE in the list, and turn it on. Only WhatsApp and SMS/Messages notifications are read.");
        notifNote.setTextColor(Color.rgb(0,150,190));
        notifNote.setTextSize(11);
        notifNote.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        LinearLayout.LayoutParams nnp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        nnp.topMargin = dp(8);
        root.addView(notifNote, nnp);

        // Hands-free mode (works with the screen off, via a background service)
        boolean handsfree = prefs.getBoolean(KEY_HANDSFREE, false);
        Button hfToggle = new Button(this);
        hfToggle.setAllCaps(false);
        hfToggle.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        hfToggle.setText(handsfree ? "[ HANDS-FREE (SCREEN OFF): ON ]" : "[ HANDS-FREE (SCREEN OFF): OFF ]");
        hfToggle.setTextColor(Color.rgb(0,225,255));
        hfToggle.setOnClickListener(v -> {
            SharedPreferences p = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean cur = p.getBoolean(KEY_HANDSFREE, false);
            boolean next = !cur;
            p.edit().putBoolean(KEY_HANDSFREE, next).apply();
            hfToggle.setText(next ? "[ HANDS-FREE (SCREEN OFF): ON ]" : "[ HANDS-FREE (SCREEN OFF): OFF ]");
            android.content.Intent svc = new android.content.Intent(this, MikeBackgroundService.class);
            if (next) {
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(svc); else startService(svc);
                Toast.makeText(this, "Hands-free is on. Mike will keep listening for \"Hey Mike\" even with the screen off, until you turn this off or the phone kills the background service.", Toast.LENGTH_LONG).show();
            } else {
                stopService(svc);
                Toast.makeText(this, "Hands-free turned off.", Toast.LENGTH_SHORT).show();
            }
        });
        LinearLayout.LayoutParams hftp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        hftp.topMargin = dp(20);
        root.addView(hfToggle, hftp);

        Button batterySettings = new Button(this);
        batterySettings.setAllCaps(false);
        batterySettings.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        batterySettings.setText("[ OPEN BATTERY / AUTOSTART SETTINGS ]");
        batterySettings.setTextColor(Color.rgb(0,180,220));
        batterySettings.setOnClickListener(v -> {
            try{ startActivity(new android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:"+getPackageName()))); }
            catch(Exception e){ Toast.makeText(this,"Could not open app settings.",Toast.LENGTH_SHORT).show(); }
        });
        LinearLayout.LayoutParams bsp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        bsp.topMargin = dp(10);
        root.addView(batterySettings, bsp);

        TextView hfNote = new TextView(this);
        hfNote.setText("Battery-hungry, and some phones kill background apps by default. From the button above, allow MIKE to run in the background / disable battery optimization / enable Autostart, or hands-free may stop after a while.");
        hfNote.setTextColor(Color.rgb(0,150,190));
        hfNote.setTextSize(11);
        hfNote.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        LinearLayout.LayoutParams hfnp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hfnp.topMargin = dp(8);
        root.addView(hfNote, hfnp);

        // Save button
        Button save = new Button(this);
        save.setAllCaps(false);
        save.setText("[ SAVE ]");
        save.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        save.setTextColor(Color.rgb(0,225,255));
        save.setOnClickListener(v -> {
            SharedPreferences.Editor e = prefs.edit();
            String city = cityInput.getText().toString().trim();
            if (city.isEmpty()) city = "Pune";
            e.putString(KEY_CITY, city);
            String uname = nameInput.getText().toString().trim();
            e.putString(KEY_USER_NAME, uname.isEmpty()?"Boss":uname);
            e.putInt(KEY_SPEECH_RATE, rateSeek.getProgress() + 50);
            e.apply();
            Toast.makeText(this, "Settings saved.", Toast.LENGTH_SHORT).show();
            finish();
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        sp.topMargin = dp(30);
        root.addView(save, sp);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }
}
